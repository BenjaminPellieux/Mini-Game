"""try:
	import scrapy
except BaseException as u:
	print("Type: " + u.__class__.__name__)
	print(type(u.__class__.__name__))
	if u.__class__.__name__=="ModuleNotFoundError":
		print("bob")
"""







try:
    if a == 1:
        print( "ok")
except Exception as u:
    print ("bonjour"+str(u),type(u))